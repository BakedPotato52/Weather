const url = 'https://weather-by-api-ninjas.p.rapidapi.com/v1/weather?city=Agartala';

const options = {
  method: 'GET',
  headers: {
    'X-RapidAPI-Key': '26cc1b0a71mshb503fea2aeedb25p122b05jsnc916465ec9b1',
    'X-RapidAPI-Host': 'weather-by-api-ninjas.p.rapidapi.com'
  }
};

const getWeather = (city) => {
  cityName.innerHTML = city;
  fetch(`https://weather-by-api-ninjas.p.rapidapi.com/v1/weather?city=`+ city, options)
    .then(response => response.json())
    .then((data) => {
      console.log(data);
      temp.innerHTML = data.temp;
      humidity.innerHTML = data.humidity;
      wind_speed.innerHTML = data.wind_speed;
      cloud_pct.innerHTML = data.cloud_pct;
      feels_like.innerHTML = data.feels_like;
      min_temp.innerHTML = data.min_temp;
      max_temp.innerHTML = data.max_temp;
    })
    .catch(err => console.error(err)); // Move the catch to the correct location
};

submit.addEventListener("click", (e) => {
  e.preventDefault();
  getWeather(city.value);
});

getWeather("Agartala"); // Make sure to pass the correct city name
